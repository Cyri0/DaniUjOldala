from django.apps import AppConfig


class DaniapiConfig(AppConfig):
    name = 'daniapi'
